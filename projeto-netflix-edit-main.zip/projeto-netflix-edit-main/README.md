# projeto-netflix-edit
 Projeto criado para o curso de desenvolvimento - EDIT
